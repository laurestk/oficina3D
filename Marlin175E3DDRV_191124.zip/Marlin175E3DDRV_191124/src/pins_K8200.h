/**
 * K8200 Arduino Mega with RAMPS v1.3 pin assignments
 * Identical to 3DRAG
 */

#include "pins_3DRAG.h"
