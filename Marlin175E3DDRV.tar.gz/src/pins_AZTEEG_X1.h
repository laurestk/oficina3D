/**
 * Azteeg X1 pin assignments
 */

#define SANGUINOLOLU_V_1_2

#include "pins_SANGUINOLOLU_11.h"
